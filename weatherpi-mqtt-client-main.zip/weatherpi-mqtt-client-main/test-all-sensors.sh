#!/bin/bash
./test-atmospheric-sensors.py
./test-temp-probe.py
./test-wind-sensors.py
./test-rain-sensor.py