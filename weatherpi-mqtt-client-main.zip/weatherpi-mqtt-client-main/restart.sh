/usr/bin/python3 /home/pi/weatherpi-mqtt-client/all-sensors-to-mqtt.py > /home/pi/weatherpi-mqtt-client/weatherpi.log 2>&1 &
